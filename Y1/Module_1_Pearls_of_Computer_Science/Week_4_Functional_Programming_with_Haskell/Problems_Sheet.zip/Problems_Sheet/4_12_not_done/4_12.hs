matches :: (Eq a, Ord a) => [a] -> [a] -> Bool
matches [] _ = True
matches _ [] = False
matches (x:xs) (y:ys)
    | x == y = matches xs ys
    | otherwise = False

count_found :: (Eq a, Ord a) => [a] -> [a] -> Int
count_found 
