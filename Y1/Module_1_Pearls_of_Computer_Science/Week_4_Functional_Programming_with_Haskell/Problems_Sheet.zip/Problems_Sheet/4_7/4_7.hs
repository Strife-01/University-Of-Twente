interest a 0 p = a
interest a n p = (1 + p/100) * interest a (n - 1) p

-- a * ((100 + p) / 100)^n 
