f x = 2 * x^2 + 3 * x - 5

circ r = 2 * pi * r

area r = pi * r^2
