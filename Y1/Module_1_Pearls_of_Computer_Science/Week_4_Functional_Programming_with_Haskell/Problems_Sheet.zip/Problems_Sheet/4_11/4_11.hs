import Data.Char

--palindrome :: (Eq a, Char a, Num a, Ord a) => [a] -> Bool
palindrome :: (Eq a) => [a] -> Bool
palindrome [] = True
palindrome [_] = True
palindrome xs
    | xs == reverse xs = True
    | otherwise = False
