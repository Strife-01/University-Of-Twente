Instructions how to retarget the projects to the Windows SDK version you have installed on your system:

After open the solution in Visual Studio click "Project" -> "Retarget solution" in the top menu. Then click "OK" after selecting the correct Windows SDK Version for your own system, usually the one selected is the correct one.